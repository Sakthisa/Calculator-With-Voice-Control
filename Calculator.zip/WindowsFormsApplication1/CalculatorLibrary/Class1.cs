﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorLibrary
{
    public class Calculator
    {
        public double add(double operandOne, double operandTwo) //Performs addition
        {
            return operandOne + operandTwo;
        }
        public double subtract(double operandOne, double operandTwo) //Performs subtraction
        {
            return operandOne - operandTwo;
        }
        public double multiply(double operandOne, double operandTwo) //Performs multiplication
        {
            return operandOne * operandTwo;
        }
        public double divide(double operandOne, double operandTwo) //Performs division
        {
            return operandOne / operandTwo;
        }
        public int checkOperandTwo(double operandTwo) //Check for zero logic
        {
            int hold = 0;
            if (operandTwo == 0)
            {
                hold = 1;
            }
            else
            {
                hold = 0;
            }
            return hold;
        }
        public int decimalNumeration(int length, string numeration) //Only allows for a single decimal
        {
            int valid = 0;
            for (int i = 0; i < length; i++)
            {
                if (numeration[i].ToString() != ".")
                {
                    valid = 1;
                }
                else
                {
                    valid = 0;
                    break;
                }
            }
            return valid;
        }
        public double turnToDecimalPercent(double operand) //Convert number into a decimal percentage
        {
            return operand / 100.0;
        }
        public double changeSign(double operand) //Changes the sign of the number (positive/negative)
        {
            return operand * (-1);
        }
    }
}
