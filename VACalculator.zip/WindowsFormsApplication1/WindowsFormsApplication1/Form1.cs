﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using CalculatorLibrary;
using System.Text.RegularExpressions;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        //string previousInput = "";
        double operandone = 0.0; //User input of operand one for computation
        double operandtwo = 0.0; //User input of operand two for computation
        int hold = 0; //For logic involving the computation with numeric 0
        int mic = 0; //Whether the mic for sound control is ON or OFF
        string operation; //Determines the type of mathematical operation
        SpeechRecognitionEngine voice = new SpeechRecognitionEngine(); //Allows for speech recognition
        SpeechSynthesizer synthesizer = new SpeechSynthesizer(); //Allows for voice assistant
        Calculator cal = new Calculator(); //Used because certain functions are within a calculator class library

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button7_MouseClick(object sender, MouseEventArgs e) //Allows for numeric 7 to be clicked and displayed
        {
            numericSeven();
        }

        private void numericSeven()
        {
            if (displayButton.Text == "0")
            {
                displayButton.Text = string.Empty;
            }
            displayButton.Text += "7";
        }

        private void acButton_MouseClick(object sender, MouseEventArgs e) //Allows for AC to be clicked which clears the display
        {
            clearAC();
        }

        private void clearAC()
        {
            displayButton.Text = string.Empty;
            displayButton.Text = "0";
            operandone = 0.0;
            operandtwo = 0.0;
            hold = 0;
            previewText.Text = string.Empty;
        }

        private void button5_Click_1(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void eightButton_MouseClick(object sender, MouseEventArgs e) //Allows for numeric 8 to be clicked and displayed
        {
            numericEight();
        }

        private void numericEight()
        {
            if (displayButton.Text == "0")
            {
                displayButton.Text = string.Empty;
            }
            displayButton.Text += "8";
        }

        private void nineButton_MouseClick(object sender, MouseEventArgs e) //Allows for numeric 9 to be clicked and displayed
        {
            numericNine();
        }

        private void numericNine()
        {
            if (displayButton.Text == "0")
            {
                displayButton.Text = string.Empty;
            }
            displayButton.Text += "9";
        }

        private void fourButton_MouseClick(object sender, MouseEventArgs e) //Allows for numeric 4 to be clicked and displayed
        {
            numericFour();
        }

        private void numericFour()
        {
            if (displayButton.Text == "0")
            {
                displayButton.Text = string.Empty;
            }
            displayButton.Text += "4";
        }

        private void fiveButton_MouseClick(object sender, MouseEventArgs e) //Allows for numeric 5 to be clicked and displayed
        {
            numericFive();
        }

        private void numericFive()
        {
            if (displayButton.Text == "0")
            {
                displayButton.Text = string.Empty;
            }
            displayButton.Text += "5";
        }

        private void sixButton_MouseClick(object sender, MouseEventArgs e) //Allows for numeric 6 to be clicked and displayed
        {
            numericSix();
        }

        private void numericSix()
        {
            if (displayButton.Text == "0")
            {
                displayButton.Text = string.Empty;
            }
            displayButton.Text += "6";
        }

        private void oneButton_MouseClick(object sender, MouseEventArgs e) //Allows for numeric 1 to be clicked and displayed
        {
            numericOne();
        }

        private void numericOne()
        {
            if (displayButton.Text == "0")
            {
                displayButton.Text = string.Empty;
            }
            displayButton.Text += "1";
        }

        private void twoButton_MouseClick(object sender, MouseEventArgs e) //Allows for numeric 2 to be clicked and displayed
        {
            numericTwo();
        }

        private void numericTwo()
        {
            if (displayButton.Text == "0")
            {
                displayButton.Text = string.Empty;
            }
            displayButton.Text += "2";
        }

        private void threeButton_MouseClick(object sender, MouseEventArgs e) //Allows for numeric 3 to be clicked and displayed
        {
            numericThree();
        }

        private void numericThree()
        {
            if (displayButton.Text == "0")
            {
                displayButton.Text = string.Empty;
            }
            displayButton.Text += "3";
        }

        private void zeroButton_MouseClick(object sender, MouseEventArgs e) //Allows for numeric 0 to be clicked and displayed
        {
            numericZero();

        }

        private void numericZero()
        {
            if (displayButton.Text == "0")
            {
                displayButton.Text = string.Empty;
            }
            displayButton.Text += "0";
        }

        private void decimalButton_MouseClick(object sender, MouseEventArgs e) //Allows for user to input a single decimal
        {
            decimalAdd();
        }

        private void decimalAdd()
        {
            int length = 0;
            string numeration;
            int valid = 0;
            length = displayButton.Text.Length;
            numeration = displayButton.Text.ToString();
            valid = CalculatorLibrary.Calculator.decimalNumeration(length, numeration);
            if (valid == 1 || length == 0)
            {
                displayButton.Text += ".";
            }
        }

        private void addButton_MouseClick(object sender, MouseEventArgs e) //Allows for user to perform addition
        {
            addition();
        }

        private void addition()
        {
            operandtwo = 0;
            hold = 0;
            if (operandone == 0.0)
            {
                operandone = Double.Parse(displayButton.Text);

            }
            operation = "+";
            displayButton.Text = string.Empty;
            displayButton.Text = "0";
            previewText.Text = operandone + " + ";
        }

        private void equalButton_MouseClick(object sender, MouseEventArgs e) //Allows user to perform computation between two numbers
        {
            equals();
        }

        private void equals()
        {
            if ((operandtwo == 0 && hold == 0))
            {
                operandtwo = Double.Parse(displayButton.Text);
                hold = CalculatorLibrary.Calculator.checkOperandTwo(operandtwo);
            }
            double result = 0.0;
            previewText.Text = string.Empty;
            if (operation == "+")
            {
                result = CalculatorLibrary.Calculator.add(operandone, operandtwo);
                displayButton.Text = result.ToString();
                operandone = result;
            }
            if (operation == "-")
            {
                result = CalculatorLibrary.Calculator.subtract(operandone, operandtwo);
                displayButton.Text = result.ToString();
                operandone = result;
            }
            if (operation == "*")
            {
                result = CalculatorLibrary.Calculator.multiply(operandone, operandtwo);
                displayButton.Text = result.ToString();
                operandone = result;
            }
            if (operation == "/")
            {
                result = CalculatorLibrary.Calculator.divide(operandone, operandtwo);
                displayButton.Text = result.ToString();
                operandone = result;
            }
            if (checkBox1.Checked == true)
            {
                synthesizer.Volume = trackBar1.Value * 10;
                synthesizer.SpeakAsync("The result is " + displayButton.Text);
            }
        }

        private void subtractionButton_MouseClick(object sender, MouseEventArgs e) //Allows user to perform subtraction between two operands
        {
            subtraction();
        }

        private void subtraction()
        {
            operandtwo = 0;
            hold = 0;
            if (operandone == 0.0)
            {
                operandone = Double.Parse(displayButton.Text);
            }
            operation = "-";
            displayButton.Text = string.Empty;
            displayButton.Text = "0";
            previewText.Text = operandone + " − ";
        }

        private void multButton_MouseClick(object sender, MouseEventArgs e) //Allows user to perform multiplication between two operands
        {
            multiplication();
        }

        private void multiplication()
        {
            operandtwo = 0;
            hold = 0;
            if (operandone == 0.0)
            {
                operandone = Double.Parse(displayButton.Text);

            }
            operation = "*";
            displayButton.Text = string.Empty;
            displayButton.Text = "0";
            previewText.Text = operandone + " ✕ ";
        }

        private void divideButton_MouseClick(object sender, MouseEventArgs e) //Allows user to perform division between two operands
        {
            division();
        }

        private void division()
        {
            operandtwo = 0;
            hold = 0;
            if (operandone == 0.0)
            {
                operandone = Double.Parse(displayButton.Text);

            }
            operation = "/";
            displayButton.Text = string.Empty;
            displayButton.Text = "0";
            previewText.Text = operandone + " ÷ ";
        }

        private void percentButton_MouseClick(object sender, MouseEventArgs e) //Converts any number into a decimal representation of a percentage
        {
            percent();
        }

        private void percent()
        {
            if (previewText.Text != string.Empty)
            {
                operandtwo = Double.Parse(displayButton.Text);
                operandtwo = CalculatorLibrary.Calculator.turnToDecimalPercent(operandtwo);
                displayButton.Text = operandtwo.ToString();
            }
            else
            {
                operandone = Double.Parse(displayButton.Text);
                operandone = CalculatorLibrary.Calculator.turnToDecimalPercent(operandone);
                displayButton.Text = operandone.ToString();
            }
        }

        private void negButton_MouseClick(object sender, MouseEventArgs e) //Changes the sign of the number (positive/negative)
        {
            changeSign();
        }

        private void changeSign()
        {
            if (previewText.Text != string.Empty)
            {
                operandtwo = Double.Parse(displayButton.Text);
                operandtwo = CalculatorLibrary.Calculator.changeSign(operandtwo);
                displayButton.Text = operandtwo.ToString();
            }
            else
            {
                operandone = Double.Parse(displayButton.Text);
                operandone = CalculatorLibrary.Calculator.changeSign(operandone);
                displayButton.Text = operandone.ToString();
            }
        }

        private void Form1_Load(object sender, EventArgs e) //Allows for voice recognition
        {
            Choices commands = new Choices();
            commands.Add(new string[] { "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "zero" , "plus", "equals", "disable voice control", "minus", "times", "divided by", "percent", "change sign", "clear", "point", "close calculator", "disable voice assistant", "enable voice assistant"}); //Voice options
            GrammarBuilder gBuilder = new GrammarBuilder();
            gBuilder.Append(commands);
            Grammar grammar = new Grammar(gBuilder);

            voice.LoadGrammarAsync(grammar);
            voice.SetInputToDefaultAudioDevice();
            voice.SpeechRecognized += voice_SpeechRecognized;

        }
        void voice_SpeechRecognized(object sender, SpeechRecognizedEventArgs e) //Different voice cases that conduct all the actions seen above
        {
            switch (e.Result.Text)
            {
                case "one":
                    numericOne();
                    break;
                case "two":
                    numericTwo();
                    break;
                case "three":
                    numericThree();
                    break;
                case "four":
                    numericFour();
                    break;
                case "five":
                    numericFive();
                    break;
                case "six":
                    numericSix();
                    break;
                case "seven":
                    numericSeven();
                    break;
                case "eight":
                    numericEight();
                    break;
                case "nine":
                    numericNine();
                    break;
                case "zero":
                    numericZero();
                    break;
                case "plus":
                    addition();
                    break;
                case "equals":
                    equals();
                    break;
                case "disable voice control":
                    if (checkBox1.Checked == true)
                    {
                        synthesizer.Volume = trackBar1.Value * 10;
                        synthesizer.SpeakAsync("Disabling voice control.");
                    }
                    button3.BackgroundImage = Properties.Resources.MICOFF;
                    voice.RecognizeAsyncStop();
                    mic = 0;
                    break;
                case "minus":
                    subtraction();
                    break;
                case "times":
                    multiplication();
                    break;
                case "divided by":
                    division();
                    break;
                case "percent":
                    percent();
                    break;
                case "change sign":
                    changeSign();
                    break;
                case "clear":
                    clearAC();
                    break;
                case "point":
                    decimalAdd();
                    break;
                case "close calculator":
                    this.Close();
                    break;
                case "disable voice assistant":
                    if(checkBox1.Checked == true)
                    {
                        checkBox1.Checked = false;
                    }
                    break;
                case "enable voice assistant":
                    if (checkBox1.Checked == false)
                    {
                        checkBox1.Checked = true;
                    }
                    break;
            }
        }

        private void displayButton_TextChanged(object sender, EventArgs e)
        {

        }

        private void previewText_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e) //Either disables or enables the mic for voice recognition (uses default audio device)
        {
            if (mic == 0)
            {
                if (checkBox1.Checked == true)
                {
                    synthesizer.Volume = trackBar1.Value * 10;
                    synthesizer.SpeakAsync("Enabling voice control.");
                }
                button3.BackgroundImage = Properties.Resources.MICON2;
                voice.RecognizeAsync(RecognizeMode.Multiple);
                mic = 1;
            }
            else
            {
                if (checkBox1.Checked == true)
                {
                    synthesizer.Volume = trackBar1.Value * 10;
                    synthesizer.SpeakAsync("Disabling voice control.");
                }
                button3.BackgroundImage = Properties.Resources.MICOFF;
                voice.RecognizeAsyncStop();
                mic = 0;
            }
        }

        private void check1(object sender, EventArgs e)
        {

        }

        private void displayButton_KeyPress(object sender, KeyPressEventArgs e) //Ensures that only integers and a single decimal can be displayed on the textbox
        {
            char ch = e.KeyChar;
            decimal x;
            if (ch == (char)Keys.Back)
            {
                e.Handled = false;
            }
            else if (!char.IsDigit(ch) && ch != '.' || !Decimal.TryParse(displayButton.Text + ch, out x))
            {
                e.Handled = true;
            }

        }
    }
 
}