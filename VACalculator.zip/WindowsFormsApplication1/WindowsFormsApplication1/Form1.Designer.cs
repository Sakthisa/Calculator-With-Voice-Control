﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.negButton = new System.Windows.Forms.Button();
            this.percentButton = new System.Windows.Forms.Button();
            this.divideButton = new System.Windows.Forms.Button();
            this.displayButton = new System.Windows.Forms.RichTextBox();
            this.sevenButton = new System.Windows.Forms.Button();
            this.eightButton = new System.Windows.Forms.Button();
            this.nineButton = new System.Windows.Forms.Button();
            this.multButton = new System.Windows.Forms.Button();
            this.subtractionButton = new System.Windows.Forms.Button();
            this.sixButton = new System.Windows.Forms.Button();
            this.fiveButton = new System.Windows.Forms.Button();
            this.fourButton = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.threeButton = new System.Windows.Forms.Button();
            this.twoButton = new System.Windows.Forms.Button();
            this.oneButton = new System.Windows.Forms.Button();
            this.equalButton = new System.Windows.Forms.Button();
            this.decimalButton = new System.Windows.Forms.Button();
            this.zeroButton = new System.Windows.Forms.Button();
            this.acButton = new System.Windows.Forms.Button();
            this.tipDisplay = new System.Windows.Forms.ToolTip(this.components);
            this.button3 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.previewText = new System.Windows.Forms.RichTextBox();
            this.helpProvider = new System.Windows.Forms.HelpProvider();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.SuspendLayout();
            // 
            // negButton
            // 
            this.negButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.negButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.negButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.negButton.ForeColor = System.Drawing.Color.Black;
            this.negButton.Location = new System.Drawing.Point(72, 110);
            this.negButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.negButton.Name = "negButton";
            this.negButton.Size = new System.Drawing.Size(60, 28);
            this.negButton.TabIndex = 1;
            this.negButton.Text = "+/-";
            this.tipDisplay.SetToolTip(this.negButton, "Change number to positive or negative");
            this.negButton.UseVisualStyleBackColor = false;
            this.negButton.Click += new System.EventHandler(this.button2_Click);
            this.negButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.negButton_MouseClick);
            // 
            // percentButton
            // 
            this.percentButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.percentButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.percentButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.percentButton.ForeColor = System.Drawing.Color.Black;
            this.percentButton.Location = new System.Drawing.Point(140, 110);
            this.percentButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.percentButton.Name = "percentButton";
            this.percentButton.Size = new System.Drawing.Size(60, 28);
            this.percentButton.TabIndex = 2;
            this.percentButton.Text = "%";
            this.tipDisplay.SetToolTip(this.percentButton, "Change to decimal percentage representation");
            this.percentButton.UseVisualStyleBackColor = false;
            this.percentButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.percentButton_MouseClick);
            // 
            // divideButton
            // 
            this.divideButton.BackColor = System.Drawing.Color.Orange;
            this.divideButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.divideButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.divideButton.ForeColor = System.Drawing.Color.White;
            this.divideButton.Location = new System.Drawing.Point(208, 110);
            this.divideButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.divideButton.Name = "divideButton";
            this.divideButton.Size = new System.Drawing.Size(60, 28);
            this.divideButton.TabIndex = 3;
            this.divideButton.Text = "÷";
            this.tipDisplay.SetToolTip(this.divideButton, "Divide operator");
            this.divideButton.UseVisualStyleBackColor = false;
            this.divideButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.divideButton_MouseClick);
            // 
            // displayButton
            // 
            this.displayButton.BackColor = System.Drawing.Color.White;
            this.displayButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayButton.Location = new System.Drawing.Point(0, 16);
            this.displayButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.displayButton.Name = "displayButton";
            this.displayButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.displayButton.Size = new System.Drawing.Size(263, 68);
            this.displayButton.TabIndex = 4;
            this.displayButton.Text = "0";
            this.displayButton.TextChanged += new System.EventHandler(this.displayButton_TextChanged);
            this.displayButton.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.displayButton_KeyPress);
            // 
            // sevenButton
            // 
            this.sevenButton.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.sevenButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sevenButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sevenButton.ForeColor = System.Drawing.Color.White;
            this.sevenButton.Location = new System.Drawing.Point(4, 145);
            this.sevenButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sevenButton.Name = "sevenButton";
            this.sevenButton.Size = new System.Drawing.Size(60, 28);
            this.sevenButton.TabIndex = 5;
            this.sevenButton.Text = "7";
            this.sevenButton.UseVisualStyleBackColor = false;
            this.sevenButton.Click += new System.EventHandler(this.button5_Click);
            this.sevenButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.button7_MouseClick);
            // 
            // eightButton
            // 
            this.eightButton.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.eightButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.eightButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.eightButton.ForeColor = System.Drawing.Color.White;
            this.eightButton.Location = new System.Drawing.Point(72, 145);
            this.eightButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.eightButton.Name = "eightButton";
            this.eightButton.Size = new System.Drawing.Size(60, 28);
            this.eightButton.TabIndex = 6;
            this.eightButton.Text = "8";
            this.eightButton.UseVisualStyleBackColor = false;
            this.eightButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.eightButton_MouseClick);
            // 
            // nineButton
            // 
            this.nineButton.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.nineButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.nineButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nineButton.ForeColor = System.Drawing.Color.White;
            this.nineButton.Location = new System.Drawing.Point(140, 145);
            this.nineButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nineButton.Name = "nineButton";
            this.nineButton.Size = new System.Drawing.Size(60, 28);
            this.nineButton.TabIndex = 9;
            this.nineButton.Text = "9";
            this.nineButton.UseVisualStyleBackColor = false;
            this.nineButton.Click += new System.EventHandler(this.button5_Click_1);
            this.nineButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.nineButton_MouseClick);
            // 
            // multButton
            // 
            this.multButton.BackColor = System.Drawing.Color.Orange;
            this.multButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.multButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.multButton.ForeColor = System.Drawing.Color.White;
            this.multButton.Location = new System.Drawing.Point(208, 145);
            this.multButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.multButton.Name = "multButton";
            this.multButton.Size = new System.Drawing.Size(60, 28);
            this.multButton.TabIndex = 8;
            this.multButton.Text = "✕";
            this.tipDisplay.SetToolTip(this.multButton, "Multiplication operator");
            this.multButton.UseVisualStyleBackColor = false;
            this.multButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.multButton_MouseClick);
            // 
            // subtractionButton
            // 
            this.subtractionButton.BackColor = System.Drawing.Color.Orange;
            this.subtractionButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.subtractionButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.subtractionButton.ForeColor = System.Drawing.Color.White;
            this.subtractionButton.Location = new System.Drawing.Point(208, 181);
            this.subtractionButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.subtractionButton.Name = "subtractionButton";
            this.subtractionButton.Size = new System.Drawing.Size(60, 28);
            this.subtractionButton.TabIndex = 12;
            this.subtractionButton.Text = "−";
            this.tipDisplay.SetToolTip(this.subtractionButton, "Minus Operator");
            this.subtractionButton.UseVisualStyleBackColor = false;
            this.subtractionButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.subtractionButton_MouseClick);
            // 
            // sixButton
            // 
            this.sixButton.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.sixButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sixButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sixButton.ForeColor = System.Drawing.Color.White;
            this.sixButton.Location = new System.Drawing.Point(140, 181);
            this.sixButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sixButton.Name = "sixButton";
            this.sixButton.Size = new System.Drawing.Size(60, 28);
            this.sixButton.TabIndex = 13;
            this.sixButton.Text = "6";
            this.sixButton.UseVisualStyleBackColor = false;
            this.sixButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.sixButton_MouseClick);
            // 
            // fiveButton
            // 
            this.fiveButton.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.fiveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.fiveButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fiveButton.ForeColor = System.Drawing.Color.White;
            this.fiveButton.Location = new System.Drawing.Point(72, 181);
            this.fiveButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.fiveButton.Name = "fiveButton";
            this.fiveButton.Size = new System.Drawing.Size(60, 28);
            this.fiveButton.TabIndex = 11;
            this.fiveButton.Text = "5";
            this.fiveButton.UseVisualStyleBackColor = false;
            this.fiveButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.fiveButton_MouseClick);
            // 
            // fourButton
            // 
            this.fourButton.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.fourButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.fourButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fourButton.ForeColor = System.Drawing.Color.White;
            this.fourButton.Location = new System.Drawing.Point(4, 181);
            this.fourButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.fourButton.Name = "fourButton";
            this.fourButton.Size = new System.Drawing.Size(60, 28);
            this.fourButton.TabIndex = 10;
            this.fourButton.Text = "4";
            this.fourButton.UseVisualStyleBackColor = false;
            this.fourButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.fourButton_MouseClick);
            // 
            // addButton
            // 
            this.addButton.BackColor = System.Drawing.Color.Orange;
            this.addButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addButton.ForeColor = System.Drawing.Color.White;
            this.addButton.Location = new System.Drawing.Point(208, 217);
            this.addButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(60, 28);
            this.addButton.TabIndex = 16;
            this.addButton.Text = "+";
            this.tipDisplay.SetToolTip(this.addButton, "Plus operator");
            this.addButton.UseVisualStyleBackColor = false;
            this.addButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.addButton_MouseClick);
            // 
            // threeButton
            // 
            this.threeButton.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.threeButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.threeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.threeButton.ForeColor = System.Drawing.Color.White;
            this.threeButton.Location = new System.Drawing.Point(140, 217);
            this.threeButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.threeButton.Name = "threeButton";
            this.threeButton.Size = new System.Drawing.Size(60, 28);
            this.threeButton.TabIndex = 17;
            this.threeButton.Text = "3";
            this.threeButton.UseVisualStyleBackColor = false;
            this.threeButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.threeButton_MouseClick);
            // 
            // twoButton
            // 
            this.twoButton.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.twoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.twoButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.twoButton.ForeColor = System.Drawing.Color.White;
            this.twoButton.Location = new System.Drawing.Point(72, 217);
            this.twoButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.twoButton.Name = "twoButton";
            this.twoButton.Size = new System.Drawing.Size(60, 28);
            this.twoButton.TabIndex = 15;
            this.twoButton.Text = "2";
            this.twoButton.UseVisualStyleBackColor = false;
            this.twoButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.twoButton_MouseClick);
            // 
            // oneButton
            // 
            this.oneButton.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.oneButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.oneButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.oneButton.ForeColor = System.Drawing.Color.White;
            this.oneButton.Location = new System.Drawing.Point(4, 217);
            this.oneButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.oneButton.Name = "oneButton";
            this.oneButton.Size = new System.Drawing.Size(60, 28);
            this.oneButton.TabIndex = 14;
            this.oneButton.Text = "1";
            this.oneButton.UseVisualStyleBackColor = false;
            this.oneButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.oneButton_MouseClick);
            // 
            // equalButton
            // 
            this.equalButton.BackColor = System.Drawing.Color.Orange;
            this.equalButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.equalButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.equalButton.ForeColor = System.Drawing.Color.White;
            this.equalButton.Location = new System.Drawing.Point(208, 252);
            this.equalButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.equalButton.Name = "equalButton";
            this.equalButton.Size = new System.Drawing.Size(60, 28);
            this.equalButton.TabIndex = 20;
            this.equalButton.Text = "=";
            this.tipDisplay.SetToolTip(this.equalButton, "Equals operator");
            this.equalButton.UseVisualStyleBackColor = false;
            this.equalButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.equalButton_MouseClick);
            // 
            // decimalButton
            // 
            this.decimalButton.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.decimalButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.decimalButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.decimalButton.ForeColor = System.Drawing.Color.White;
            this.decimalButton.Location = new System.Drawing.Point(140, 252);
            this.decimalButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.decimalButton.Name = "decimalButton";
            this.decimalButton.Size = new System.Drawing.Size(60, 28);
            this.decimalButton.TabIndex = 21;
            this.decimalButton.Text = ".";
            this.tipDisplay.SetToolTip(this.decimalButton, "Decimal");
            this.decimalButton.UseVisualStyleBackColor = false;
            this.decimalButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.decimalButton_MouseClick);
            // 
            // zeroButton
            // 
            this.zeroButton.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.zeroButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.zeroButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.zeroButton.ForeColor = System.Drawing.Color.White;
            this.zeroButton.Location = new System.Drawing.Point(4, 252);
            this.zeroButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.zeroButton.Name = "zeroButton";
            this.zeroButton.Size = new System.Drawing.Size(128, 28);
            this.zeroButton.TabIndex = 18;
            this.zeroButton.Text = "0";
            this.zeroButton.UseVisualStyleBackColor = false;
            this.zeroButton.Click += new System.EventHandler(this.button12_Click);
            this.zeroButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.zeroButton_MouseClick);
            // 
            // acButton
            // 
            this.acButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.acButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.acButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.acButton.ForeColor = System.Drawing.Color.Black;
            this.acButton.Location = new System.Drawing.Point(4, 110);
            this.acButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.acButton.Name = "acButton";
            this.acButton.Size = new System.Drawing.Size(60, 28);
            this.acButton.TabIndex = 0;
            this.acButton.Text = "AC";
            this.tipDisplay.SetToolTip(this.acButton, "Clear all values");
            this.acButton.UseVisualStyleBackColor = false;
            this.acButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.acButton_MouseClick);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources._default;
            this.button3.Location = new System.Drawing.Point(215, 324);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(53, 50);
            this.button3.TabIndex = 27;
            this.tipDisplay.SetToolTip(this.button3, "Voice Recognition");
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(84, 288);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(126, 21);
            this.checkBox1.TabIndex = 28;
            this.checkBox1.Text = "Voice Assistant";
            this.tipDisplay.SetToolTip(this.checkBox1, "Enable voice assistant");
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.check1);
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(4, 319);
            this.trackBar1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(196, 56);
            this.trackBar1.TabIndex = 29;
            this.tipDisplay.SetToolTip(this.trackBar1, "Volume adjust for voice assistant");
            this.trackBar1.Value = 5;
            // 
            // previewText
            // 
            this.previewText.BackColor = System.Drawing.Color.White;
            this.previewText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.previewText.Location = new System.Drawing.Point(11, 52);
            this.previewText.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.previewText.Name = "previewText";
            this.previewText.ReadOnly = true;
            this.previewText.Size = new System.Drawing.Size(252, 32);
            this.previewText.TabIndex = 26;
            this.previewText.Text = "";
            this.previewText.TextChanged += new System.EventHandler(this.previewText_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(279, 377);
            this.Controls.Add(this.trackBar1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.previewText);
            this.Controls.Add(this.equalButton);
            this.Controls.Add(this.decimalButton);
            this.Controls.Add(this.zeroButton);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.threeButton);
            this.Controls.Add(this.twoButton);
            this.Controls.Add(this.oneButton);
            this.Controls.Add(this.subtractionButton);
            this.Controls.Add(this.sixButton);
            this.Controls.Add(this.fiveButton);
            this.Controls.Add(this.fourButton);
            this.Controls.Add(this.multButton);
            this.Controls.Add(this.nineButton);
            this.Controls.Add(this.eightButton);
            this.Controls.Add(this.sevenButton);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.divideButton);
            this.Controls.Add(this.percentButton);
            this.Controls.Add(this.negButton);
            this.Controls.Add(this.acButton);
            this.HelpButton = true;
            this.helpProvider.SetHelpString(this, resources.GetString("$this.HelpString"));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.helpProvider.SetShowHelp(this, true);
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button acButton;
        private System.Windows.Forms.Button negButton;
        private System.Windows.Forms.Button percentButton;
        private System.Windows.Forms.Button divideButton;
        private System.Windows.Forms.RichTextBox displayButton;
        private System.Windows.Forms.Button sevenButton;
        private System.Windows.Forms.Button eightButton;
        private System.Windows.Forms.Button nineButton;
        private System.Windows.Forms.Button multButton;
        private System.Windows.Forms.Button subtractionButton;
        private System.Windows.Forms.Button sixButton;
        private System.Windows.Forms.Button fiveButton;
        private System.Windows.Forms.Button fourButton;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Button threeButton;
        private System.Windows.Forms.Button twoButton;
        private System.Windows.Forms.Button oneButton;
        private System.Windows.Forms.Button equalButton;
        private System.Windows.Forms.Button decimalButton;
        private System.Windows.Forms.Button zeroButton;
        private System.Windows.Forms.ToolTip tipDisplay;
        private System.Windows.Forms.RichTextBox previewText;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.HelpProvider helpProvider;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TrackBar trackBar1;
    }
}

