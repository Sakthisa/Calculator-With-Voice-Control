﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Calculator_Test
{
    [TestClass]
    public class CalculatorTest
    {
        [TestMethod]
        public void TestAddition() //Test addition logic
        {
            double expected = 37;
            double operandone = 32;
            double operandtwo = 5;
            double actual = CalculatorLibrary.Calculator.add(operandone, operandtwo);
            Assert.AreEqual(expected, actual);


            expected = -20;
            operandone = 10;
            operandtwo = -30;
            actual = CalculatorLibrary.Calculator.add(operandone, operandtwo);
            Assert.AreEqual(expected, actual);


            expected = 5;
            operandone = 5;
            operandtwo = 0;
            actual = CalculatorLibrary.Calculator.add(operandone, operandtwo);
            Assert.AreEqual(expected, actual);


            expected = -5;
            operandone = -5;
            operandtwo = 0;
            actual = CalculatorLibrary.Calculator.add(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = -10;
            operandone = -5;
            operandtwo = -5;
            actual = CalculatorLibrary.Calculator.add(operandone, operandtwo);
            Assert.AreEqual(expected, actual);


            expected = 3.2;
            operandone = 4;
            operandtwo = -.8;
            actual = CalculatorLibrary.Calculator.add(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 0;
            operandone = 0;
            operandtwo = 0;
            actual = CalculatorLibrary.Calculator.add(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            string expectedString = "50";
            string operandoneString = "40";
            string operandtwoString = "10";
            string actualString = CalculatorLibrary.Calculator.add(double.Parse(operandoneString), double.Parse(operandtwoString)).ToString();
            Assert.AreEqual(expectedString, actualString);


        }

        [TestMethod]
        public void TestSubtraction() //Test subtraction logic
        {
            double expected = 22;
            double operandone = 32;
            double operandtwo = 10;
            double actual = CalculatorLibrary.Calculator.subtract(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = -22;
            operandone = 10;
            operandtwo = 32;
            actual = CalculatorLibrary.Calculator.subtract(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 22;
            operandone = -10;
            operandtwo = -32;
            actual = CalculatorLibrary.Calculator.subtract(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = -52;
            operandone = -10;
            operandtwo = 42;
            actual = CalculatorLibrary.Calculator.subtract(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = -5;
            operandone = 0;
            operandtwo = 5;
            actual = CalculatorLibrary.Calculator.subtract(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 51;
            operandone = 51;
            operandtwo = 0;
            actual = CalculatorLibrary.Calculator.subtract(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 5.2;
            operandone = 6;
            operandtwo = .8;
            actual = CalculatorLibrary.Calculator.subtract(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 0;
            operandone = -1;
            operandtwo = -1;
            actual = CalculatorLibrary.Calculator.subtract(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 2000000000000000000;
            operandone = 3000000000000000000;
            operandtwo = 1000000000000000000;
            actual = CalculatorLibrary.Calculator.subtract(operandone, operandtwo);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMultiplication() //Test multiplication logic
        {
            double expected = 15;
            double operandone = 5;
            double operandtwo = 3;
            double actual = CalculatorLibrary.Calculator.multiply(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 15;
            operandone = 3;
            operandtwo = 5;
            actual = CalculatorLibrary.Calculator.multiply(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 0;
            operandone = 3000000000000000000;
            operandtwo = 0;
            actual = CalculatorLibrary.Calculator.multiply(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 0;
            operandone = 0;
            operandtwo = 3000000000000000000;
            actual = CalculatorLibrary.Calculator.multiply(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = -25;
            operandone = -5;
            operandtwo = 5;
            actual = CalculatorLibrary.Calculator.multiply(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 20;
            operandone = -4;
            operandtwo = -5;
            actual = CalculatorLibrary.Calculator.multiply(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 100000000;
            operandone = 10000;
            operandtwo = 10000;
            actual = CalculatorLibrary.Calculator.multiply(operandone, operandtwo);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestDivision() //Test division logic
        {
            double expected = 15;
            double operandone = 30;
            double operandtwo = 2;
            double actual = CalculatorLibrary.Calculator.divide(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = .5;
            operandone = 13;
            operandtwo = 26;
            actual = CalculatorLibrary.Calculator.divide(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = -10;
            operandone = -30;
            operandtwo = 3;
            actual = CalculatorLibrary.Calculator.divide(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 10;
            operandone = -30;
            operandtwo = -3;
            actual = CalculatorLibrary.Calculator.divide(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 0;
            operandone = 0;
            operandtwo = -3;
            actual = CalculatorLibrary.Calculator.divide(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = double.NaN;
            operandone = 0;
            operandtwo = 0;
            actual = CalculatorLibrary.Calculator.divide(operandone, operandtwo);
            Assert.AreEqual(expected, actual);

            expected = double.PositiveInfinity;
            operandone = 50;
            operandtwo = 0;
            actual = CalculatorLibrary.Calculator.divide(operandone, operandtwo);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestZeroLogic() //Test zero logic
        {
            double expected = 0;
            double operandtwo = 2;
            double actual = CalculatorLibrary.Calculator.checkOperandTwo(operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 0;
            operandtwo = -2;
            actual = CalculatorLibrary.Calculator.checkOperandTwo(operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 0;
            operandtwo = 2.1;
            actual = CalculatorLibrary.Calculator.checkOperandTwo(operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 0;
            operandtwo = -4.16;
            actual = CalculatorLibrary.Calculator.checkOperandTwo(operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 0;
            operandtwo = 0.16;
            actual = CalculatorLibrary.Calculator.checkOperandTwo(operandtwo);
            Assert.AreEqual(expected, actual);

            expected = 1;
            operandtwo = 0.00;
            actual = CalculatorLibrary.Calculator.checkOperandTwo(operandtwo);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void testDecimal() //Test Decimal adding logic
        {
            int expected = 1;
            string number = "sachin";
            int actual = CalculatorLibrary.Calculator.decimalNumeration(number.Length, number);
            Assert.AreEqual(expected, actual);

            expected = 0;
            number = "5.0";
            actual = CalculatorLibrary.Calculator.decimalNumeration(number.Length, number);
            Assert.AreEqual(expected, actual);

            expected = 0;
            number = ".5.0";
            actual = CalculatorLibrary.Calculator.decimalNumeration(number.Length, number);
            Assert.AreEqual(expected, actual);

            expected = 0;
            number = "50000.0000";
            actual = CalculatorLibrary.Calculator.decimalNumeration(number.Length, number);
            Assert.AreEqual(expected, actual);

            expected = 0;
            number = "500000000.";
            actual = CalculatorLibrary.Calculator.decimalNumeration(number.Length, number);
            Assert.AreEqual(expected, actual);

            expected = 1;
            number = "50";
            actual = CalculatorLibrary.Calculator.decimalNumeration(number.Length, number);
            Assert.AreEqual(expected, actual);

            expected = 0;
            number = "-5.0";
            actual = CalculatorLibrary.Calculator.decimalNumeration(number.Length, number);
            Assert.AreEqual(expected, actual);

            expected = 0;
            number = "5-.0";
            actual = CalculatorLibrary.Calculator.decimalNumeration(number.Length, number);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestDecimalPercent() //Test decimal percent logic
        {
            double expected = 0.02;
            double operand = 2;
            double actual = CalculatorLibrary.Calculator.turnToDecimalPercent(operand);
            Assert.AreEqual(expected, actual);

            expected = 0.2;
            operand = 20;
            actual = CalculatorLibrary.Calculator.turnToDecimalPercent(operand);
            Assert.AreEqual(expected, actual);

            expected = 2;
            operand = 200;
            actual = CalculatorLibrary.Calculator.turnToDecimalPercent(operand);
            Assert.AreEqual(expected, actual);

            expected = -0.05;
            operand = -5;
            actual = CalculatorLibrary.Calculator.turnToDecimalPercent(operand);
            Assert.AreEqual(expected, actual);

            expected = 0;
            operand = 0;
            actual = CalculatorLibrary.Calculator.turnToDecimalPercent(operand);
            Assert.AreEqual(expected, actual);

            expected = 1;
            operand = 100;
            actual = CalculatorLibrary.Calculator.turnToDecimalPercent(operand);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestChangeSign() //Test sign change logic
        {
            double expected = -0.02;
            double operand = 0.02;
            double actual = CalculatorLibrary.Calculator.changeSign(operand);
            Assert.AreEqual(expected, actual);

            expected = 5.02;
            operand = -5.02;
            actual = CalculatorLibrary.Calculator.changeSign(operand);
            Assert.AreEqual(expected, actual);

            expected = 2;
            operand = -2;
            actual = CalculatorLibrary.Calculator.changeSign(operand);
            Assert.AreEqual(expected, actual);

            expected = 0;
            operand = 0;
            actual = CalculatorLibrary.Calculator.changeSign(operand);
            Assert.AreEqual(expected, actual);
        }
    }
}
